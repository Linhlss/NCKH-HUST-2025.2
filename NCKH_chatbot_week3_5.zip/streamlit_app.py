from __future__ import annotations

import json
import re
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, List, Tuple
from urllib import error, parse, request

import streamlit as st


BASE_DIR = Path(__file__).resolve().parent
CONFIG_FILE = BASE_DIR / "config" / "tenants.json"
DATA_FILES_DIR = BASE_DIR / "data" / "files"
PIPELINE1_DIR = BASE_DIR / "pipeline1"
GENERATED_QA_PATH = PIPELINE1_DIR / "generated_qa.json"
LORA_DATASET_PATH = PIPELINE1_DIR / "lora_dataset.json"


def http_json(method: str, url: str, payload: Dict[str, Any] | None = None) -> Dict[str, Any]:
    data = None
    headers = {}
    if payload is not None:
        data = json.dumps(payload).encode("utf-8")
        headers["Content-Type"] = "application/json"

    req = request.Request(url=url, method=method.upper(), data=data, headers=headers)
    try:
        with request.urlopen(req, timeout=120) as resp:
            text = resp.read().decode("utf-8")
            return json.loads(text) if text else {}
    except error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="ignore")
        try:
            parsed = json.loads(body)
        except Exception:
            parsed = {"message": body or str(exc)}
        raise RuntimeError(f"{exc.code} {exc.reason}: {parsed}")
    except error.URLError as exc:
        raise RuntimeError(f"Không kết nối được API: {exc}")


def load_tenant_configs() -> Dict[str, Dict[str, Any]]:
    if not CONFIG_FILE.exists():
        return {}
    return json.loads(CONFIG_FILE.read_text(encoding="utf-8"))


def save_tenant_configs(configs: Dict[str, Dict[str, Any]]) -> None:
    CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(configs, ensure_ascii=False, indent=2), encoding="utf-8")


def normalize_tenant_id(raw: str) -> str:
    normalized = re.sub(r"[^a-z0-9_]+", "_", raw.lower()).strip("_")
    return normalized or "tenant_moi"


def run_pipeline1() -> Tuple[int, str]:
    cmd = [sys.executable, str(PIPELINE1_DIR / "run_pipeline1.py")]
    proc = subprocess.run(
        cmd,
        cwd=str(BASE_DIR),
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    output = (proc.stdout or "") + ("\n" + proc.stderr if proc.stderr else "")
    return proc.returncode, output.strip()


def count_json_records(path: Path) -> int:
    if not path.exists():
        return 0
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return 0
    return len(data) if isinstance(data, list) else 0


def ensure_data_dir() -> None:
    DATA_FILES_DIR.mkdir(parents=True, exist_ok=True)


st.set_page_config(page_title="Multi-tenant RAG Control Panel", page_icon=":robot_face:", layout="wide")
st.title("Multi-tenant RAG Control Panel")
st.caption("UI nền cho demo NCKH: chat đa-tenant, quản lý tenant và chuẩn bị dữ liệu LoRA.")

with st.sidebar:
    st.subheader("API")
    api_base = st.text_input("API base URL", value="http://127.0.0.1:8000")
    tenant_configs = load_tenant_configs()
    tenant_options = sorted(tenant_configs.keys()) or ["default"]
    selected_tenant = st.selectbox("Tenant", tenant_options, index=0)
    user_id = st.text_input("User ID", value="guest")
    show_sources = st.checkbox("Hiện nguồn", value=True)

tab_chat, tab_runtime, tab_tenants, tab_lora = st.tabs(
    ["Chat", "Runtime", "Tenant Config", "LoRA Workspace"]
)

with tab_chat:
    st.subheader("Chat theo tenant")
    question = st.text_area("Câu hỏi", placeholder="Nhập câu hỏi cho chatbot...")
    if st.button("Gửi câu hỏi", type="primary"):
        if not question.strip():
            st.warning("Bạn chưa nhập câu hỏi.")
        else:
            payload = {
                "tenant_id": selected_tenant,
                "user_id": user_id.strip() or "guest",
                "message": question.strip(),
                "show_sources": show_sources,
            }
            try:
                resp = http_json("POST", f"{api_base.rstrip('/')}/chat", payload)
                st.success(f"Route: {resp.get('route', 'unknown')} | Mode: {resp.get('mode', 'unknown')}")
                st.markdown("### Trả lời")
                st.write(resp.get("answer", ""))
                sources = resp.get("sources") or []
                if sources:
                    st.markdown("### Nguồn")
                    st.dataframe(sources, use_container_width=True)
                meta = resp.get("metadata") or {}
                if meta:
                    st.markdown("### Metadata")
                    st.json(meta)
            except Exception as exc:
                st.error(str(exc))

with tab_runtime:
    st.subheader("Trạng thái runtime")
    col1, col2, col3 = st.columns(3)

    with col1:
        if st.button("Kiểm tra /health"):
            try:
                st.json(http_json("GET", f"{api_base.rstrip('/')}/health"))
            except Exception as exc:
                st.error(str(exc))

    with col2:
        if st.button("Xem /status"):
            query = parse.urlencode({"tenant_id": selected_tenant, "user_id": user_id.strip() or "guest"})
            try:
                st.json(http_json("GET", f"{api_base.rstrip('/')}/status?{query}"))
            except Exception as exc:
                st.error(str(exc))

    with col3:
        if st.button("Refresh Index Tenant"):
            try:
                st.json(
                    http_json(
                        "POST",
                        f"{api_base.rstrip('/')}/refresh",
                        {"tenant_id": selected_tenant},
                    )
                )
            except Exception as exc:
                st.error(str(exc))

    if st.button("Reset Chat Memory"):
        try:
            st.json(
                http_json(
                    "POST",
                    f"{api_base.rstrip('/')}/memory/reset",
                    {"tenant_id": selected_tenant, "user_id": user_id.strip() or "guest"},
                )
            )
        except Exception as exc:
            st.error(str(exc))

with tab_tenants:
    st.subheader("Quản lý tenant cho shared-model + adapter")
    tenant_configs = load_tenant_configs()
    if not tenant_configs:
        st.info("Chưa có tenant config.")
    else:
        st.dataframe(
            [
                {
                    "tenant_id": tenant_id,
                    "display_name": cfg.get("display_name", tenant_id),
                    "model_name": cfg.get("model_name", "llama3"),
                    "adapter_name": cfg.get("adapter_name", "base"),
                    "top_k": cfg.get("top_k", 4),
                    "memory_turns": cfg.get("memory_turns", 6),
                }
                for tenant_id, cfg in sorted(tenant_configs.items())
            ],
            use_container_width=True,
        )

    st.markdown("### Cập nhật tenant hiện tại")
    current_cfg = tenant_configs.get(selected_tenant, {})
    with st.form("tenant_update_form"):
        display_name = st.text_input("Display name", value=current_cfg.get("display_name", selected_tenant))
        model_name = st.text_input("Model name", value=current_cfg.get("model_name", "llama3"))
        adapter_name = st.text_input("Adapter name", value=current_cfg.get("adapter_name", "base"))
        top_k = st.number_input("Top K", min_value=1, max_value=20, value=int(current_cfg.get("top_k", 4)))
        memory_turns = st.number_input(
            "Memory turns",
            min_value=1,
            max_value=30,
            value=int(current_cfg.get("memory_turns", 6)),
        )
        language_hint = st.text_input(
            "Language hint",
            value=current_cfg.get("language_hint", "Tự động theo ngôn ngữ câu hỏi"),
        )
        persona = st.text_area(
            "Persona",
            value=current_cfg.get("persona", "Bạn là trợ lý tư vấn doanh nghiệp."),
            height=120,
        )
        submitted = st.form_submit_button("Lưu tenant config")
        if submitted:
            tenant_configs[selected_tenant] = {
                "display_name": display_name.strip() or selected_tenant,
                "persona": persona.strip(),
                "language_hint": language_hint.strip() or "Tự động",
                "top_k": int(top_k),
                "memory_turns": int(memory_turns),
                "model_name": model_name.strip() or "llama3",
                "adapter_name": adapter_name.strip() or "base",
            }
            save_tenant_configs(tenant_configs)
            st.success("Đã lưu tenants.json.")

    st.markdown("### Tạo tenant mới")
    with st.form("tenant_create_form"):
        raw_tenant_id = st.text_input("Tenant ID mới (text tự do)")
        tenant_display = st.text_input("Display name tenant mới")
        create_submitted = st.form_submit_button("Tạo tenant")
        if create_submitted:
            tenant_id = normalize_tenant_id(raw_tenant_id.strip())
            if tenant_id in tenant_configs:
                st.warning(f"Tenant `{tenant_id}` đã tồn tại.")
            else:
                tenant_configs[tenant_id] = {
                    "display_name": tenant_display.strip() or tenant_id,
                    "persona": "Bạn là trợ lý tư vấn doanh nghiệp.",
                    "language_hint": "Tự động theo ngôn ngữ câu hỏi",
                    "top_k": 5,
                    "memory_turns": 6,
                    "model_name": "llama3",
                    "adapter_name": "base",
                }
                save_tenant_configs(tenant_configs)
                st.success(f"Đã tạo tenant `{tenant_id}`. Reload trang để thấy trong dropdown.")

with tab_lora:
    st.subheader("LoRA Workspace (nền cho Dương)")
    st.caption("Bước hiện tại: upload `.txt` vào data/files, sinh QA dataset, export JSON train LoRA.")
    ensure_data_dir()

    uploader = st.file_uploader(
        "Upload tài liệu txt cho pipeline1",
        type=["txt"],
        accept_multiple_files=True,
    )
    if uploader:
        saved = 0
        for item in uploader:
            target = DATA_FILES_DIR / item.name
            target.write_bytes(item.getbuffer())
            saved += 1
        st.success(f"Đã lưu {saved} file vào {DATA_FILES_DIR}.")

    txt_files: List[Path] = sorted(DATA_FILES_DIR.glob("*.txt"))
    st.markdown("### Danh sách file nguồn hiện có")
    if txt_files:
        st.dataframe(
            [{"file": p.name, "size_kb": round(p.stat().st_size / 1024, 2)} for p in txt_files],
            use_container_width=True,
        )
    else:
        st.info("Chưa có file txt trong data/files.")

    if st.button("Chạy pipeline1 (generate QA + export LoRA)"):
        with st.spinner("Đang chạy pipeline1..."):
            code, output = run_pipeline1()
        if code == 0:
            st.success("Pipeline1 chạy thành công.")
        else:
            st.error(f"Pipeline1 lỗi (exit code {code}).")
        st.code(output or "(không có output)", language="text")

    st.markdown("### Tình trạng dataset")
    col_a, col_b = st.columns(2)
    with col_a:
        st.metric("generated_qa.json records", count_json_records(GENERATED_QA_PATH))
        st.caption(str(GENERATED_QA_PATH))
    with col_b:
        st.metric("lora_dataset.json records", count_json_records(LORA_DATASET_PATH))
        st.caption(str(LORA_DATASET_PATH))

    st.markdown(
        "Gợi ý cho bước tiếp theo của Dương: dùng `lora_dataset.json` để train adapter riêng cho từng tenant, "
        "sau đó cập nhật `adapter_name` trong tenant config."
    )
